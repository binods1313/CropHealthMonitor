
import React, { useState, useMemo, useRef, useEffect } from 'react';
/* Fix: Re-importing useNavigate and useLocation from react-router-dom to fix reported missing export errors */
import { useNavigate, useLocation } from 'react-router-dom';
import { MOCK_FARMS, NDVI_STATS, REGIONS, generateNearbyFarms, generateFallbackImageUrl } from '../constants';
import { analyzeFarmHealth } from '../services/geminiService';
import { generateDualFarmImages } from '../services/farmImageService';
import { fetchRealTimeWeather, fetchForecast } from '../services/weatherService';
import { getSavedReports, deleteSavedReport } from '../services/storageService';
import FarmMap from './FarmMap';
import SavedReportsModal from './SavedReportsModal';
import FarmEditModal from './FarmEditModal';
import FarmDiscoveryCard from './FarmDiscoveryCard';
import Footer from './Footer';
import { FarmData, WeatherData, SavedReport, Region, ForecastDay } from '../types';
import { 
  LayoutDashboard, Activity, ShieldAlert, Leaf, Settings, History, Search, 
  Navigation, Beaker, Cloud, Sparkles, ChevronRight, Wind, CheckCircle, 
  ArrowUpRight, ChevronDown, Sun, CloudRain, CloudLightning, Snowflake,
  Maximize2, TestTube2, Thermometer, Droplets,
  ThermometerSun,
  ThermometerSnowflake,
  Droplet,
  Globe,
  Facebook,
  Twitter,
  Instagram,
  Mail,
  Phone,
  CreditCard,
  MapPin,
  Map,
  Zap,
  Target
} from 'lucide-react';
import { useTheme } from '../ThemeContext';
import ConfigModal from './ConfigModal';

// --- Vedic Sacred Geometry Components ---

const HealthPattern = ({ color }: { color: string }) => (
  <div className="absolute -top-12 -right-12 w-64 h-64 pointer-events-none group-hover:scale-110 transition-transform duration-[2000ms] ease-out z-0">
    <svg viewBox="0 0 200 200" className="w-full h-full opacity-[0.48] group-hover:opacity-[0.8] transition-opacity duration-700 animate-spin-extra-slow" fill="none" stroke={color} strokeWidth="1.2">
      <circle cx="100" cy="100" r="8" fill={color} fillOpacity="0.15" />
      {[0, 45, 90, 135, 180, 225, 270, 315].map(deg => (
        <g key={deg} transform={`rotate(${deg} 100 100)`}>
          <path d="M100 92 C 110 70, 130 70, 100 30 C 70 70, 90 70, 100 92" />
        </g>
      ))}
      <circle cx="100" cy="100" r="50" strokeDasharray="2 6" />
      <circle cx="100" cy="100" r="95" className="animate-pulse-gentle" strokeWidth="1.5" />
    </svg>
  </div>
);

const ClimatePattern = ({ color }: { color: string }) => (
  <div className="absolute -top-12 -right-12 w-64 h-64 pointer-events-none group-hover:scale-110 transition-transform duration-[2000ms] ease-out z-0">
    <svg viewBox="0 0 200 200" className="w-full h-full opacity-[0.48] group-hover:opacity-[0.8] transition-opacity duration-700 animate-spin-reverse-slow" fill="none" stroke={color} strokeWidth="1.2">
      <circle cx="100" cy="100" r="32" />
      {[0, 60, 120, 180, 240, 300].map(deg => {
        const rad = (deg * Math.PI) / 180;
        return <circle key={deg} cx={100 + 32 * Math.cos(rad)} cy={100 + 32 * Math.sin(rad)} r="32" />;
      })}
      <circle cx="100" cy="100" r="98" className="animate-pulse-gentle" strokeWidth="1.5" />
    </svg>
  </div>
);

const RiskPattern = ({ color }: { color: string }) => (
  <div className="absolute -top-12 -right-12 w-64 h-64 pointer-events-none group-hover:scale-110 transition-transform duration-[2000ms] ease-out z-0">
    <svg viewBox="0 0 200 200" className="w-full h-full opacity-[0.48] group-hover:opacity-[0.8] transition-opacity duration-700 animate-spin-extra-slow" fill="none" stroke={color} strokeWidth="1.2">
      <path d="M100 15 L180 165 L20 165 Z" />
      <path d="M100 185 L20 35 L180 35 Z" opacity="0.7" />
      <circle cx="100" cy="100" r="25" />
    </svg>
  </div>
);

interface DashboardCardData {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  icon: React.ElementType;
  color: string;
  gradient: string;
  route: string;
  vedicType: 'health' | 'climate' | 'risk';
}

const DASHBOARD_CARDS: DashboardCardData[] = [
  {
    id: 'health',
    title: 'HEALTH',
    subtitle: 'PRECIZION NDVI INTEL',
    description: 'Deep-spectral analysis of crop vigor indices.',
    icon: Leaf,
    color: '#10b981',
    gradient: 'linear-gradient(135deg, rgba(16, 185, 129, 0.15) 0%, rgba(16, 185, 129, 0.05) 100%)',
    route: '/',
    vedicType: 'health'
  },
  {
    id: 'climate',
    title: 'CLIMATE',
    subtitle: 'RESILIENCE & EMISSIONS',
    description: '2030 climate adaptation roadmaps.',
    icon: Cloud,
    color: '#3b82f6',
    gradient: 'linear-gradient(135deg, rgba(59, 130, 246, 0.15) 0%, rgba(59, 130, 246, 0.05) 100%)',
    route: '/climate',
    vedicType: 'climate'
  },
  {
    id: 'risks',
    title: 'RISKS',
    subtitle: 'TACTICAL THREAT DETECTION',
    description: 'Surveillance of disaster vectors.',
    icon: ShieldAlert,
    color: '#f43f5e',
    gradient: 'linear-gradient(135deg, rgba(244, 63, 94, 0.15) 0%, rgba(244, 63, 94, 0.05) 100%)',
    route: '/disasters',
    vedicType: 'risk'
  }
];

const MagicalDirectiveCard: React.FC<{ 
  card: DashboardCardData, 
  isActive: boolean, 
  onClick: () => void 
}> = ({ card, isActive, onClick }) => {
  return (
    <button
      onClick={onClick}
      className={`relative group overflow-hidden rounded-[2rem] p-8 text-left transition-all duration-700 w-full min-h-[220px] flex flex-col justify-between border-[2px] backdrop-blur-3xl
        ${isActive ? 'scale-[1.05] z-10' : 'hover:-translate-y-3 hover:scale-[1.02]'}`}
      style={{ 
        backgroundColor: 'rgba(255, 255, 255, 0.02)',
        borderColor: isActive ? card.color : 'rgba(255, 255, 255, 0.08)',
        boxShadow: isActive 
          ? `0 0 40px -10px ${card.color}40, inset 0 0 20px ${card.color}10` 
          : `0 15px 35px -10px rgba(0,0,0,0.5)`
      }}
    >
      <div className="absolute inset-0 transition-opacity duration-700" style={{ background: card.gradient, opacity: isActive ? 1 : 0.4 }} />
      {card.vedicType === 'health' && <HealthPattern color={card.color} />}
      {card.vedicType === 'climate' && <ClimatePattern color={card.color} />}
      {card.vedicType === 'risk' && <RiskPattern color={card.color} />}
      
      <div className="relative z-10 w-full">
        <div className="flex items-start justify-between mb-6">
          <div className="p-4 rounded-xl shadow-xl transition-all duration-500 group-hover:rotate-[15deg] group-hover:scale-110 border border-white/10" style={{ backgroundColor: 'rgba(255, 255, 255, 0.03)', color: card.color }}>
            <card.icon size={28} strokeWidth={2.5} />
          </div>
        </div>
        <div className="space-y-1">
          <h2 className="text-2xl font-black tracking-tighter text-white uppercase italic">{card.title}</h2>
          <p className="text-[10px] font-black tracking-widest uppercase text-stone-500">{card.subtitle}</p>
        </div>
      </div>
      
      {isActive && (
        <div className="absolute bottom-4 right-4 flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 backdrop-blur-md border border-white/10 shadow-xl">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-[8px] font-black text-white uppercase tracking-widest">Active</span>
        </div>
      )}
    </button>
  );
};

const TacticalMetric: React.FC<{ label: string, value: string | number, unit: string, icon: React.ElementType, color: string }> = ({ label, value, unit, icon: Icon, color }) => (
  <div className="relative group overflow-hidden rounded-[2.5rem] p-8 bg-white transition-all duration-700 border-[3.5px] hover:scale-[1.03] hover:-translate-y-1 min-h-[250px] flex flex-col items-center justify-center text-center dashboard-card-glow"
       style={{ 
         borderColor: color,
         boxShadow: `0 10px 40px -10px ${color}30`,
       }}>
    <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundColor: color }} />
    <div className="flex flex-col items-center gap-6 relative z-10 w-full">
      <div className="p-3.5 rounded-2xl shadow-lg transition-all duration-500 group-hover:rotate-6 group-hover:scale-110 bg-white border border-stone-100 shrink-0 animate-marker-pulse" style={{ color }}>
        <Icon size={28} strokeWidth={3} />
      </div>
      <div className="flex items-baseline gap-2 justify-center">
        <span className="text-6xl font-black text-stone-900 tracking-tighter leading-none">{value}</span>
        <span className="text-sm font-black text-stone-400 uppercase tracking-[0.2em]">{unit}</span>
      </div>
      <div className="px-5 py-2.5 rounded-2xl flex items-center justify-center min-h-[44px] w-full" style={{ backgroundColor: `${color}10` }}>
        <p className="text-sm font-black tracking-tight uppercase leading-tight text-center" style={{ color }}>{label}</p>
      </div>
    </div>
  </div>
);

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { accentColor } = useTheme();

  const [allFarms, setAllFarms] = useState<FarmData[]>(MOCK_FARMS.slice(0, 8));
  const [activeFarm, setActiveFarm] = useState<FarmData>(allFarms[0]);
  const [isConfigOpen, setIsConfigOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isFarmSelectorOpen, setIsFarmSelectorOpen] = useState(false);
  const [weather, setWeather] = useState<WeatherData>(activeFarm.weather);
  const [forecast, setForecast] = useState<ForecastDay[]>([]);
  const [analyzing, setAnalyzing] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [savedReports, setSavedReports] = useState<SavedReport[]>([]);

  // Robustly derive nearby farms from the mock dataset instead of random generation
  const nearbyFarms = useMemo(() => {
    return allFarms
      .filter(f => f.id !== activeFarm.id)
      .sort((a, b) => {
        // Simple Euclidean distance for proximity sorting
        const distA = Math.sqrt(Math.pow(a.lat - activeFarm.lat, 2) + Math.pow(a.lon - activeFarm.lon, 2));
        const distB = Math.sqrt(Math.pow(b.lat - activeFarm.lat, 2) + Math.pow(b.lon - activeFarm.lon, 2));
        return distA - distB;
      })
      .slice(0, 4);
  }, [activeFarm, allFarms]);

  useEffect(() => { setSavedReports(getSavedReports()); }, []);
  
  useEffect(() => {
    const syncWeather = async () => {
      try {
        const [liveData, forecastData] = await Promise.all([
          fetchRealTimeWeather(activeFarm.lat, activeFarm.lon),
          fetchForecast(activeFarm.lat, activeFarm.lon)
        ]);
        setWeather(liveData);
        setForecast(forecastData);
      } catch (error) { console.warn("Weather telemetry interrupted."); }
    };
    syncWeather();
  }, [activeFarm]);

  const handleFarmSelect = (farm: FarmData) => { 
    setActiveFarm(farm); 
    setIsFarmSelectorOpen(false); 
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleInitializeDiagnosis = async () => {
    if (analyzing) return;
    setAnalyzing(true);
    try {
        const visualAssets = await generateDualFarmImages(activeFarm);
        const result = await analyzeFarmHealth(activeFarm, NDVI_STATS, "", activeFarm.soil);
        navigate(`/report/${activeFarm.id}`, { state: { farm: activeFarm, report: result, generatedImages: visualAssets } });
    } catch (e) { console.error("Diagnosis critical failure."); } finally { setAnalyzing(false); }
  };

  return (
    <div className="min-h-screen bg-[#fcfcfb] flex flex-col relative overflow-x-hidden">
      <nav className="bg-stone-950/80 backdrop-blur-2xl border-b border-white/5 sticky top-0 z-[60] px-8 py-5 flex items-center justify-between shadow-2xl">
        <div className="flex items-center gap-10">
          <div className="flex items-center gap-3 cursor-pointer group" onClick={() => navigate('/')}>
            <div className="p-2 rounded-lg shadow-2xl transition-transform group-hover:rotate-[15deg] group-hover:scale-110" style={{ backgroundColor: accentColor }}>
              <Leaf size={20} className="text-white" strokeWidth={2.5} />
            </div>
            <span className="font-black text-white tracking-tighter text-xl uppercase italic">
              CROPHEALTH <span style={{ color: accentColor }}>AI</span>
            </span>
          </div>
          <div className="hidden lg:flex items-center gap-2">
            {[
              { id: '/', label: 'HEALTH', icon: Leaf, color: '#10b981' },
              { id: '/climate', label: 'CLIMATE', icon: Cloud, color: '#3b82f6' },
              { id: '/disasters', label: 'RISKS', icon: ShieldAlert, color: '#f43f5e' }
            ].map(link => {
              const isActive = link.id === '/' ? location.pathname === '/' : location.pathname.startsWith(link.id);
              return (
                <button 
                  key={link.id}
                  onClick={() => navigate(link.id)}
                  className={`px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-3 transition-all
                    ${isActive ? 'bg-white/10 text-white border border-white/20' : 'text-stone-500 hover:text-white'}`}
                  style={{ color: isActive ? accentColor : undefined }}
                >
                  <link.icon size={14} strokeWidth={isActive ? 3 : 2.5} />
                  {link.label}
                </button>
              );
            })}
          </div>
        </div>
        <div className="flex items-center gap-4">
           <div className="hidden md:flex items-center gap-2 pr-4 border-r border-white/10">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_#10b981]" />
              <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest italic">L5.Neural_Ready</span>
           </div>
          <button onClick={() => setIsConfigOpen(true)} className="p-2.5 hover:bg-white/10 rounded-xl text-stone-400 hover:text-white transition-all">
            <Settings size={20} />
          </button>
        </div>
      </nav>

      <ConfigModal isOpen={isConfigOpen} onClose={() => setIsConfigOpen(false)} />
      
      {analyzing && (
        <div className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-3xl flex flex-col items-center justify-center animate-fade-in p-12 text-center text-white">
          <div className="w-40 h-40 relative mb-16">
            <div className="absolute inset-0 border-[6px] border-white/10 rounded-full" />
            <div className="absolute inset-0 border-[6px] rounded-full animate-spin" style={{ borderTopColor: accentColor }} />
            <div className="absolute inset-0 flex items-center justify-center"><Zap size={56} style={{ color: accentColor }} className="animate-pulse" /></div>
          </div>
          <h2 className="text-5xl font-black mb-4 tracking-tighter uppercase italic">Initializing Deep Scan</h2>
          <p className="text-emerald-400 font-bold uppercase tracking-[0.6em] text-xs">AI Core Synchronizing with Satellite Pass L2_RGB...</p>
        </div>
      )}

      <main className="flex-1 w-full bg-stone-950">
        {/* HERO SECTION REDESIGN */}
        <section className="relative pt-32 pb-48 overflow-hidden bg-stone-950">
          {/* Enhanced Forest Background */}
          <div className="absolute inset-0 z-0">
            <img src="https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&q=80&w=2560" className="w-full h-full object-cover scale-105 blur-[3px] brightness-[0.25]" alt="Canopy" />
            <div className="absolute inset-0 bg-gradient-to-b from-stone-950/80 via-stone-950/40 to-stone-950" />
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(16,185,129,0.05)_0%,transparent_70%)]" />
          </div>

          <div className="max-w-[1400px] mx-auto px-8 relative z-10 space-y-24">
            <div className="flex flex-col items-center text-center max-w-5xl mx-auto space-y-10">
              <div className="space-y-12">
                {/* Visual Accent: Thin neon line */}
                <div className="flex justify-center mb-8">
                   <div className="h-1 w-32 rounded-full shadow-[0_0_20px_var(--accent-main)] animate-pulse" style={{ backgroundColor: accentColor }} />
                </div>

                <div className="space-y-4">
                  <h1 className="text-[12px] md:text-[14px] font-black text-white/50 uppercase tracking-[1em] mb-4">
                    AUTONOMOUS
                  </h1>
                  <h2 className="text-5xl md:text-8xl font-black text-white tracking-tighter leading-[0.8] uppercase italic">
                    INTELLIGENCE PIPELINE
                  </h2>
                </div>

                <p className="text-xl md:text-3xl font-bold text-white/90 leading-tight max-w-3xl mx-auto tracking-tight">
                  Select a specialized neural module to generate site-specific interventions and adaptation roadmaps.
                </p>

                {/* Philosophy Quote Integration */}
                <div className="pt-8">
                   <p className="text-[11px] md:text-[13px] font-black uppercase tracking-[0.5em] italic opacity-40 group hover:opacity-100 transition-opacity cursor-default">
                     Precision is not just data — it’s the <span style={{ color: accentColor }}>future of farming</span>
                   </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {DASHBOARD_CARDS.map((card) => (
                <MagicalDirectiveCard 
                  key={card.id} 
                  card={card} 
                  isActive={location.pathname === card.route || (card.id === 'health' && location.pathname === '/')} 
                  onClick={() => navigate(card.route)} 
                />
              ))}
            </div>
          </div>
        </section>

        {/* Transition content area with lighter background */}
        <div className="max-w-[1400px] mx-auto px-8 -mt-20 relative z-20 space-y-24">
          <section className="bg-white rounded-[4rem] shadow-2xl border border-stone-100 p-16 relative overflow-hidden">
            <div className="flex flex-col lg:flex-row gap-20 items-start relative z-10">
              <div className="flex-1 w-full space-y-16">
                <div className="space-y-8 relative">
                  <button 
                    onClick={() => setIsFarmSelectorOpen(!isFarmSelectorOpen)} 
                    className={`w-full text-left bg-white px-10 py-9 rounded-[3rem] border-[4px] transition-all duration-700 flex items-center justify-between cursor-pointer relative z-[61] ${isFarmSelectorOpen ? 'shadow-3xl ring-4 ring-blue-100 border-blue-400' : 'shadow-2xl hover:shadow-xl border-stone-100'}`}
                  >
                    <div className="flex items-center gap-10">
                      <div className="p-6 rounded-[2rem] shadow-inner bg-blue-50 border border-blue-100 flex items-center justify-center animate-marker-pulse text-blue-500">
                         <Target size={42} strokeWidth={2.5} />
                      </div>
                      <div>
                        <h2 className="text-5xl font-black tracking-tighter text-stone-900 leading-none">{activeFarm.name}</h2>
                        <div className="flex items-center gap-4 mt-5">
                          <span className="font-black uppercase text-[11px] tracking-[0.4em] text-white px-5 py-2 rounded-full shadow-lg" style={{ backgroundColor: accentColor }}>Target_Locked</span>
                          <span className="font-bold text-sm text-stone-400 uppercase tracking-widest flex items-center gap-2"><MapPin size={16} /> {activeFarm.location}</span>
                        </div>
                      </div>
                    </div>
                    <ChevronDown size={32} className={`text-blue-500 transition-transform duration-500 ${isFarmSelectorOpen ? 'rotate-180' : ''}`} />
                  </button>

                  {isFarmSelectorOpen && (
                    <div className="absolute top-[calc(100%+15px)] left-0 w-full bg-white rounded-[3.5rem] shadow-3xl border border-blue-100 z-[70] animate-scale-in overflow-hidden">
                      <div className="max-h-[450px] overflow-y-auto custom-scrollbar">
                        {allFarms.map((farm) => (
                          <div 
                            key={farm.id} 
                            onClick={() => handleFarmSelect(farm)} 
                            className="px-12 py-8 cursor-pointer transition-all flex justify-between items-center group/item border-b border-stone-50 last:border-none hover:bg-blue-50"
                          >
                            <div className="flex items-center gap-8">
                              <MapPin size={28} className={farm.id === activeFarm.id ? 'text-blue-600' : 'text-stone-400'} />
                              <span className={`text-2xl font-black ${farm.id === activeFarm.id ? 'text-blue-600' : 'text-stone-700'} group-hover/item:text-blue-600`}>{farm.name}</span>
                            </div>
                            {farm.id === activeFarm.id && <CheckCircle size={36} className="text-blue-600" strokeWidth={3} />}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  {/* Backdrop for dropdown closing */}
                  {isFarmSelectorOpen && <div className="fixed inset-0 z-[60]" onClick={() => setIsFarmSelectorOpen(false)} />}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                  <TacticalMetric label="Sector Size" value={activeFarm.sizeHa} unit="Ha" icon={Maximize2} color="#10b981" />
                  <TacticalMetric label="Soil pH Profile" value={activeFarm.soil.ph} unit="pH" icon={Droplet} color="#f59e0b" />
                  <TacticalMetric label="Node Temperature" value={weather.temp} unit="°C" icon={Thermometer} color="#3b82f6" />
                </div>
              </div>
              <div className="w-full lg:w-[480px] shrink-0 flex flex-col gap-12">
                <div key={activeFarm.id} className="aspect-square rounded-[4rem] overflow-hidden shadow-2xl border-[12px] border-white relative group ring-2 ring-stone-100 bg-stone-100 dashboard-card-glow">
                  <img src={activeFarm.imageUrl} className="w-full h-full object-cover transition-transform duration-[10000ms] group-hover:scale-150" alt="Satellite Preview" />
                </div>
                <div className="flex flex-col gap-6">
                    <button onClick={handleInitializeDiagnosis} disabled={analyzing} className="w-full text-white py-9 rounded-[3rem] shadow-xl transition-all flex items-center justify-center gap-6 group relative overflow-hidden active:scale-[0.97] disabled:opacity-50" style={{ backgroundColor: accentColor }}>
                        <Activity size={38} strokeWidth={3} className="relative z-10 animate-marker-pulse" />
                        <span className="text-3xl font-black tracking-tighter relative z-10 uppercase italic">Initiate Diagnosis</span>
                    </button>
                    <div className="grid grid-cols-2 gap-6">
                        <button onClick={() => setIsEditModalOpen(true)} className="bg-stone-100 text-stone-700 py-6 rounded-[2rem] flex items-center justify-center gap-4 text-xs font-black uppercase tracking-widest hover:bg-stone-200 transition-all border border-stone-200"><Settings size={20} /> Site_Profile</button>
                        <button onClick={() => setIsHistoryOpen(true)} className="bg-stone-900 text-white py-6 rounded-[2rem] flex items-center justify-center gap-4 text-xs font-black uppercase tracking-widest hover:bg-black transition-all shadow-2xl"><History size={20} /> Audit_History</button>
                    </div>
                </div>
              </div>
            </div>
          </section>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-16 pb-24">
            <div className="lg:col-span-2 space-y-10">
                <h2 className="text-[14px] font-black text-stone-400 uppercase tracking-[0.8em] flex items-center gap-5 ml-2"><div className="h-6 w-2 rounded-full" style={{ backgroundColor: accentColor }} /> Geospatial Intelligence Mesh</h2>
                <div className="h-[750px] w-full bg-white rounded-[4.5rem] shadow-2xl border border-stone-100 p-4 overflow-hidden">
                    <FarmMap farms={allFarms} activeFarmId={activeFarm.id} onSelectFarm={handleFarmSelect} className="w-full h-full rounded-[3.5rem]" />
                </div>
            </div>
            <div className="space-y-10">
                <h2 className="text-[14px] font-black text-stone-400 uppercase tracking-[0.8em] flex items-center gap-5 ml-2"><Search size={24} style={{ color: accentColor }} strokeWidth={3} /> Sector Proximity</h2>
                <div className="space-y-8 max-h-[750px] overflow-y-auto pr-6 custom-scrollbar scroll-smooth">
                    {nearbyFarms.map(farm => (<div key={farm.id} className="transition-all duration-500 hover:-translate-x-2"><FarmDiscoveryCard farm={farm} isSelected={farm.id === activeFarm.id} onSelect={handleFarmSelect} /></div>))}
                </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />

      {isHistoryOpen && (<SavedReportsModal reports={savedReports} onLoad={(r) => navigate(`/report/${r.farmId}`, { state: { farm: allFarms.find(f => f.id === r.farmId), report: r.report } })} onDelete={(id) => setSavedReports(deleteSavedReport(id))} onClose={() => setIsHistoryOpen(false)} />)}
      <FarmEditModal isOpen={isEditModalOpen} onClose={() => setIsEditModalOpen(false)} farm={activeFarm} onSave={(u) => { setAllFarms(allFarms.map(f => f.id === u.id ? u : f)); setActiveFarm(u); }} />
      <style>{`
        @keyframes spin-slow { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @keyframes pulse-gentle { 0%, 100% { opacity: 0.25; transform: scale(1); } 50% { opacity: 0.5; transform: scale(1.08); } }
        .animate-spin-extra-slow { animation: spin-slow 80s linear infinite; }
        .animate-pulse-gentle { animation: pulse-gentle 4s ease-in-out infinite; }
        @keyframes dashboard-glow { 0%, 100% { filter: brightness(1); } 50% { filter: brightness(1.1); } }
        @keyframes marker-pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.08); } }
        .dashboard-card-glow { animation: dashboard-glow 4s ease-in-out infinite; }
        .animate-marker-pulse { animation: marker-pulse 2s ease-in-out infinite; }
        .custom-scrollbar::-webkit-scrollbar { width: 8px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 20px; }
      `}</style>
    </div>
  );
};

export default Dashboard;
