
import { GoogleGenAI } from "@google/genai";
import { FarmData } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Generates two distinct images for the farm report.
 * 1. Realistic Satellite NDVI view (Raw Data).
 * 2. Clinical GIS Diagnostic Overlay (Actionable Map).
 */
export const generateDualFarmImages = async (farm: FarmData): Promise<{ ndviMap: string | null, deficiencyOverlay: string | null }> => {
  
  // Prompt 1: Realistic Sentinel-2 NDVI (Observational Data)
  const ndviPrompt = `
    Generate a high-resolution, photorealistic Sentinel-2 satellite image of a ${farm.crop} farm in ${farm.location}.
    
    VISUAL STYLE:
    - RAW SATELLITE PHOTOGRAPHY (Bird's eye view).
    - Realistic earth textures, soil details, and crop canopy visible.
    - Overlay a semi-transparent NDVI heatmap:
      * RED areas showing stressed crops/bare soil.
      * YELLOW areas showing moderate growth.
      * DEEP GREEN areas showing healthy vegetation.
    - Visuals should look like Google Earth or Sentinel Hub imagery.
    
    REQUIRED ELEMENTS:
    - A white outline defining the farm boundary.
    - A small North arrow in the corner.
    - A standard NDVI color scale bar (Red to Green gradient) in the bottom corner.
    - GPS coordinates text in small white font at the bottom.
    
    NEGATIVE CONSTRAINTS (Do NOT Include):
    - NO text boxes or speech bubbles.
    - NO icons (droplets, bugs, targets).
    - NO priority labels (P1, P2).
    - NO UI overlays or "dashboard" elements.
    - Just pure, raw scientific observation data.
  `;

  // Prompt 2: AI Diagnostic Treatment Map (Actionable Prescription)
  const diagnosticPrompt = `
    Generate a digital "Precision Agriculture Dashboard Interface" screen showing a vector map of a ${farm.crop} farm.
    
    VISUAL STYLE - STRICTLY DIGITAL/VECTOR (NOT A PHOTO):
    - Create a clean, flat vector GIS map on a dark or light grey grid background.
    - Look like a screenshot from John Deere Operations Center or Climate FieldView.
    - NO photorealistic textures. Use solid colors and hatch patterns.

    MAP CONTENT:
    - Define 3 distinct polygonal zones with thick borders:
      1. RED ZONE (Label: "P1: N-Deficiency"): Fill with diagonal red lines. Add a "Nitrogen" icon.
      2. ORANGE ZONE (Label: "P2: Water Stress"): Fill with orange dots. Add a "Droplet" icon.
      3. GREEN ZONE (Label: "Healthy"): Solid light green fill.
    
    OVERLAYS & UI ELEMENTS:
    - Add white text boxes connected to zones with lines: "Rx: Apply 120kg Urea" and "Rx: Irrigation +15mm".
    - Add distinct directional arrows showing "Machinery Path".
    - Top bar: "AI DIAGNOSTIC PLAN | CONFIDENCE 88%".
    - Side legend panel explaining the zone colors.
    
    Ensure this looks like a SOFTWARE INTERFACE or TECHNICAL SCHEMATIC, completely distinct from the satellite photo.
  `;

  try {
    const [ndviResponse, diagResponse] = await Promise.all([
      ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: { parts: [{ text: ndviPrompt }] }
      }),
      ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: { parts: [{ text: diagnosticPrompt }] }
      })
    ]);

    const extractImage = (response: any) => {
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData && part.inlineData.data) {
            return `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
          }
        }
      }
      return null;
    };

    return {
      ndviMap: extractImage(ndviResponse),
      deficiencyOverlay: extractImage(diagResponse)
    };

  } catch (error) {
    console.error("Failed to generate farm images:", error);
    return { ndviMap: null, deficiencyOverlay: null };
  }
};
